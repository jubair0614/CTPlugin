package com.mondego.utility;

public class Dummy {
	public static void main(String [] args){
		int a = 650;
		int b = 100;
		System.out.println((float)a/b);
	}

}
