package com.mondego.models;

import com.mondego.indexbased.TermSearcher;

public class QueryCandidates {
    public TermSearcher termSearcher;
    public QueryBlock queryBlock;

}
