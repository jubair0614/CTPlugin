#!/bin/bash
rm Log_*
rm -rf *index
rm -rf input/dataset/oldData
rm scriptinator_metadata.scc
